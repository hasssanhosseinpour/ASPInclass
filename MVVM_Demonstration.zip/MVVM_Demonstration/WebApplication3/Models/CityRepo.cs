﻿/*
Repository Model 
•	 Each repository model provides shared CRUD logic for either one entity or for one view model.  
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Models {
    public class CityRepo {
        public void Create(string cityName, string region, int population) { 
            City city        = new City();
            city.cityName    = cityName;
            city.regionName  = region;
            city.totalPeople = population;

            RegionalStatsEntities db = new RegionalStatsEntities();
            db.Cities.Add(city);
            db.SaveChanges();
        }

        public IEnumerable<City> GetAll() { 
            RegionalStatsEntities db = new RegionalStatsEntities();
            return db.Cities;
        }

        public City GetCity(string cityName, string region) { 
            RegionalStatsEntities db = new RegionalStatsEntities();
            City city = db.Cities.Where(c=>c.cityName == cityName && c.regionName == region)
                       .FirstOrDefault();
            return city;
        }

        public City Update(string cityName, string region, int population) { 
            RegionalStatsEntities db = new RegionalStatsEntities();
            City city = db.Cities.Where(c=>c.cityName == cityName && c.regionName == region)
                       .FirstOrDefault();
            city.totalPeople = population;
            // There is something missing here. Add it in.
            db.SaveChanges();
            return city;
        }

        public void DeleteCity(string cityName, string region) { 
            City city = GetCity(cityName, region);
            RegionalStatsEntities db = new RegionalStatsEntities();
            db.Cities.Remove(city);
        }
    }
}