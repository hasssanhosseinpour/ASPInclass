﻿using System;
using System.Collections.Generic;
using System.Linq;
/*
Repository Model 
•	 Each repository model provides shared CRUD logic for either one entity or for one view model.  
*/
using System.Web;
using WebApplication3.ViewModels;

namespace WebApplication3.Models {
    public class RegionCityRepo {
        public IEnumerable<RegionCityVM> GetAll() { 
            RegionalStatsEntities db = new RegionalStatsEntities();
            IEnumerable<RegionCityVM> regionCities =
                        from r in db.Regions
                        from c in db.Cities
                        where r.regionName == c.regionName
            // Notice the * NEW SYNTAX * used here to create an object of the ViewModel type.
            select new RegionCityVM(){ CityName = c.cityName, RegionName = c.regionName, 
                                       Country = r.country, TotalPeople = (int)c.totalPeople };
            return regionCities;
        }
    }
}