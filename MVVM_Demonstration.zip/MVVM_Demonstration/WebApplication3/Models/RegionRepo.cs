﻿/*
Repository Model 
•	 Each repository model provides shared CRUD logic for either one entity or for one view model.  
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Models {
    public class RegionRepo {
        public Region CreateRegion(string regionName, string country) {
            RegionalStatsEntities db = new RegionalStatsEntities();
            Region region     = new Region();
            region.regionName = regionName;
            region.country    = country;
            db.Regions.Add(region);
            db.SaveChanges();
            return region;
        }

        public IEnumerable<Region> GetAll() { 
            RegionalStatsEntities db = new RegionalStatsEntities();
            return db.Regions;
        }

        public Region GetRegion(string regionName, string country) { 
            RegionalStatsEntities db = new RegionalStatsEntities();
            Region region = db.Regions.Where(r=>r.regionName == regionName && r.country == country)
                              .FirstOrDefault();
            return region;
        }

        public void Delete(string regionName, string country) { 
            Region region = GetRegion(regionName, country);
            RegionalStatsEntities db = new RegionalStatsEntities();
            db.Regions.Remove(region);
            db.SaveChanges();
        }
    }
}