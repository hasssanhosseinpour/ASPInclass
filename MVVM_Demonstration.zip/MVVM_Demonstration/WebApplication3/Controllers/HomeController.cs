﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication3.Models;
using WebApplication3.ViewModels;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            RegionCityRepo regionCityRepo = new RegionCityRepo();
            IEnumerable<RegionCityVM> regionCityVM = regionCityRepo.GetAll();
            int x = regionCityVM.Count();
            return View(regionCityRepo.GetAll());
        }

        // Create an Edit template for RegionCityVM.
        // When prompted * DO NOT * choose anything for the 'Data context class' since
        // the RegionCityVM does not exist the database.
        [HttpGet]
        public ActionResult Edit(string cityName, string regionName) { 
            RegionCityRepo regionCityRepo = new RegionCityRepo();
            return View();
        }

       
        [HttpPost]
        public ActionResult Edit(RegionCityVM regionCityVM) { 
            // Update the RegionCityVM through the RegionCityRepo
            return View();
        }
    }
}