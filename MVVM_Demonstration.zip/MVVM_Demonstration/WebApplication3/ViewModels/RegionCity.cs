﻿/*
View Models 
•	Define a custom type such as a unique combination of properties from a join of two or more tables. 
•	Do not contain logic.
*/

using System;

namespace WebApplication3.ViewModels {
    public class RegionCityVM {
        public string CityName    { get; set; }
        public string RegionName  { get; set; }
        public string Country     { get; set; }
        public int    TotalPeople { get; set; }

        public RegionCityVM() { }

        public RegionCityVM(string city, string region, string country, int population) {
            CityName    = city;
            RegionName  = region;
            Country     = country;
            TotalPeople = population;
        }
    }
}