﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.ViewModels;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            ViewBag.Message = "";
            return View();
        }

        //   <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.7/angular.min.js"></script>
        [HttpPost]
        public ActionResult Index(PersonVM person) 
        {
            ViewBag.Message = "Your data has been submitted.";
            // Perform 
            if (ModelState.IsValid) { 

            }
            return View();
        }
    }
}