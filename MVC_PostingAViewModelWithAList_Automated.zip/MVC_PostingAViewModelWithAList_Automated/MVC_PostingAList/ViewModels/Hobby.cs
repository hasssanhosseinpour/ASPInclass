﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_PostingAList.ViewModels
{
    public class Hobby
    {
        public string HobbyName { get; set; }
        public string Level { get; set; }

        // Parameterless constructor
        public Hobby() { }

        // Constructor with parameters.
        public Hobby(string name, string level) {
            HobbyName = name;
            Level     = level; 
        }
    }
}