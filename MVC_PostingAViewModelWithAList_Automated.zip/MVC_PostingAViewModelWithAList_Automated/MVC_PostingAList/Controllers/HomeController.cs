﻿using MVC_PostingAList.Models;
using MVC_PostingAList.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_PostingAList.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            HobbyRepo       hobbyRepo = new HobbyRepo();
            HobbyProfile hobbyProfile = hobbyRepo.GetFakeProfile();
            return View(hobbyProfile);
        }

        [HttpPost]
        public ActionResult Index(HobbyProfile model)
        {   
            // Inspect the model data here while halted. Here you will see the list of hobbies.
            return RedirectToAction("Display", "Home");
        }

        public ActionResult Display() {
            return View();
        }
    }
}
