﻿using MVC_PostingAList.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_PostingAList.Models {
    public class HobbyRepo {
        public HobbyProfile GetFakeProfile() {
            HobbyProfile hobbyProfile = new HobbyProfile();
            List<Hobby>       hobbies = new List<Hobby>();

            hobbies.Add(new Hobby("fencing", "expert"));
            hobbies.Add(new Hobby("dancing", "expert"));
            hobbies.Add(new Hobby("keyboard", "beginner"));

            hobbyProfile.Email   = "bob@home.com";
            hobbyProfile.Name    = "bob";
            hobbyProfile.hobbies = hobbies;
            return hobbyProfile;
        }
    }
}