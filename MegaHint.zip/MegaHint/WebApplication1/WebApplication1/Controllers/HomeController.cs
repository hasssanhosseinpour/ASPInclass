﻿using Assignment2Hint.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        [HttpGet]
        public ActionResult Index() {
            VolunteerSchedulerEntities db = new VolunteerSchedulerEntities();
            // If you have time you can figure out a nice way to generate this list dynamically but it is not
            // necessary.
            string[] months    = {"December 2015", "January 2016", "February 2016", 
                                  "March 2016", "April 2016", "May 2016"};
            ViewBag.Months     = months;
            ViewBag.Volunteers = db.Volunteers; // To test this insert some data for volunteers.
            return View();
        }

        [HttpPost]
        public ActionResult Index(TaskAssignmentListVM taVM) { 
            Volunteer volunteer = new Volunteer();
            // Set a breakpoint here to observe the selected values.
            // Create a repository where you save this bridge table entry.
            return RedirectToAction("Index");
        }
    }
}